package com.apple.eawt;

/** Stub class for compiling net.sf.gogui.specialmac. */
public class ApplicationAdapter
    implements ApplicationListener
{
    public ApplicationAdapter()
    {
    }

    public void handleAbout(ApplicationEvent e)
    {
    }

    public void handleOpenFile(ApplicationEvent e)
    {
    }

    public void handleQuit(ApplicationEvent e)
    {
    }
}
